<?php
	echo date('m');
?>