<?php
	include ("cn.php");
	include ("menu.php");
?>

<center>
	<h1>
		Data Saved Succesfully
	</h1>
</center>