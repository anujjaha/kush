
    <?php
    $aux = $_POST['aux'];
    echo "AUX: $aux";
	
    ?>