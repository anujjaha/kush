<?php
error_reporting(0);
session_start();
//	include ("cn.php");
//	include ("ck.php");
?>
<?php
//	require_once('ck.php');
error_reporting(0);
?><head>
	<title>
		Cybera Print MIS
	</title>
	<style>
		a{text-decoration:none; color:#0033CC; font-size:18px;}
		a:hover { color:#333333;}

	</style>	
	<link rel="shortcut icon" href="img/favicon.ico" />
</head>
<body background="img/right_bg.jpg">
<!--<body bgcolor="#BFC4E3">-->
<table align="center" border="0">
	<tr>
		<td>
			&nbsp;&nbsp;
			<a href="home.php">
			Home
			</a>
			&nbsp;&nbsp;
		</td>
		
		<td>
			&nbsp;&nbsp;
			<a href="new.php">
			New
			</a>
			&nbsp;&nbsp;
		</td>
		
		<td>
			&nbsp;&nbsp;
			<a href="view.php">
			Check Out
			</a>
			&nbsp;&nbsp;
		</td>
		
		<td>
			&nbsp;&nbsp;
			<a href="view_paid.php">
			Paid Vochers
			</a>
			&nbsp;&nbsp;
		</td>
		
		<td>
			&nbsp;&nbsp;
			<a href="search.php">
			Search
			</a>
			&nbsp;&nbsp;
		</td>
		
		<td>
			&nbsp;&nbsp;
			<a href="report.php">
			Report
			</a>
			&nbsp;&nbsp;
		</td>
		
		<td>
			&nbsp;&nbsp;
			<a href="ledger.php">
			Ledger
			</a>
			&nbsp;&nbsp;
		</td>
		
		<td>
			&nbsp;&nbsp;
			<a href="log_out.php">
			Log Out
			</a>
			&nbsp;&nbsp;
		</td>
	</tr>	

</table>