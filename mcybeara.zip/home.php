<?php
//	include ("ck.php");
	include ("menu.php");
include ("val.php");


	include ("cn.php");
	error_reporting(0);
?>
  <body>
<center>
<br>
<br>
<br>

  	

<br>
<br>
<br>
<br>
<br>


	<font style="color:#FF0000; font-size:36px;">
		Welcome to Cybera Print Art.
	</font>
<br>
<br>
<br>
<br>
<br>
<br>

<br>

	<img src="img/aj.jpg">

</center>
    </body>
    </html>