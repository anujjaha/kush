<?php

	session_start();
	$_SESSION['val'] == "false";
?>

<?php
	session_destroy();
	//header("location:index.php");
?>
<head>
	<link rel="shortcut icon" href="img/favicon.ico" />
	<title>
		Cybera Print Art MIS by ANUJ JAHA [ IT GOLD MEDALIST ]
	</title>
</head>
<body background="img/right_bg.jpg">
<br />
<br />
<br />
<br />
<br />

<center>

<img src="img/out.JPG" />
</center>